// Loads the page before loading the Java //
$(function(){
    $("div").hide().fadeIn(400);   //Fading transition between pages//
    $("a").click(function(e) {
        e.preventDefault();
        $link = $(this).attr("href");
        $("div").fadeOut(400, function() {
            window.location = $link;
        });
    });
})
